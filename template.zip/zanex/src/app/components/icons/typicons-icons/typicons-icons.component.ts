import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-typicons-icons',
  templateUrl: './typicons-icons.component.html',
  styleUrls: ['./typicons-icons.component.scss']
})
export class TypiconsIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
