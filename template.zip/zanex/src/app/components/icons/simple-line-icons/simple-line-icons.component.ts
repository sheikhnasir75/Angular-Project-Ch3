import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-line-icons',
  templateUrl: './simple-line-icons.component.html',
  styleUrls: ['./simple-line-icons.component.scss']
})
export class SimpleLineIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
