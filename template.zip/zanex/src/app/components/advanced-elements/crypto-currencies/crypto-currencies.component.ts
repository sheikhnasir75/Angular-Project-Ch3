import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crypto-currencies',
  templateUrl: './crypto-currencies.component.html',
  styleUrls: ['./crypto-currencies.component.scss']
})
export class CryptoCurrenciesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
