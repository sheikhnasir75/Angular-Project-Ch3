import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-and-popover',
  templateUrl: './tooltip-and-popover.component.html',
  styleUrls: ['./tooltip-and-popover.component.scss']
})
export class TooltipAndPopoverComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
