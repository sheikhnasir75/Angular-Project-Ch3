import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-tables',
  templateUrl: './pricing-tables.component.html',
  styleUrls: ['./pricing-tables.component.scss']
})
export class PricingTablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
