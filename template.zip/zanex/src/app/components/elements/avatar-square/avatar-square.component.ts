import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avatar-square',
  templateUrl: './avatar-square.component.html',
  styleUrls: ['./avatar-square.component.scss']
})
export class AvatarSquareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
