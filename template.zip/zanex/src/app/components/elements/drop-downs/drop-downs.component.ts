import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drop-downs',
  templateUrl: './drop-downs.component.html',
  styleUrls: ['./drop-downs.component.scss']
})
export class DropDownsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
