import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avatar-radius',
  templateUrl: './avatar-radius.component.html',
  styleUrls: ['./avatar-radius.component.scss']
})
export class AvatarRadiusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
