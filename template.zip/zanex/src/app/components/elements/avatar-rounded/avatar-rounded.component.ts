import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avatar-rounded',
  templateUrl: './avatar-rounded.component.html',
  styleUrls: ['./avatar-rounded.component.scss']
})
export class AvatarRoundedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
