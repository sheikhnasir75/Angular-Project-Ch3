import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {
  public product!: Product;
  public quantities!: Array<number>;
  public products:Array<Product>=[];

  constructor() { }

  ngOnInit() {
    
    this.product = {
      name: 'My Test Product',
      imageUrl: 'http://via.placeholder.com/150x150',
      price: 50,
      isOnSale: false,
      quantityInCart: 0
    };

 
    this.quantities = [];
    for (let i = 0; i < 20; i++) {
      this.quantities.push(i);
    }
  }

  incrementInCart() {
    this.product.quantityInCart++;
  }

  decrementInCart() {
    if (this.product.quantityInCart > 0) {
      this.product.quantityInCart--;
    }
  }

  onQtyChange(qty: any) {
    console.log('Quantity change ', qty);
  }

}
