import { ProductQuantityChange } from './product-quantity-change';

describe('ProductQuantityChange', () => {
  it('should create an instance', () => {
    expect(new ProductQuantityChange()).toBeTruthy();
  });
});
